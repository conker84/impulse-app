from __future__ import annotations

import pandas as pd
import pyspark.sql.types as T
from pyspark.sql import DataFrame

from mda_query_engine.analyze.metadata.metric_expression import MetricSelector
from mda_query_engine.analyze.metadata.tag_expression import TagSelector
from mda_query_engine.analyze.metadata.time_series_expression import (
    TimeSeriesSelector,
)
from mda_query_engine.analyze.query.solvers.empty_cache import EmptyTimeSeriesCache
from .solvers.blob_solver import BlobSolver
from .solvers.query_solver import QuerySolver


class QueryBuilder:
    def __init__(self, db: "mda_query_engine.analyze.MeasurementDB"):
        """
        Initialize the QueryBuilder.

        Parameters
        ----------
        db : mda_query_engine.analyze.MeasurementDB
            Measurement database object.

        """
        self.db = db
        self.filters = []
        self.selections = []
        self.result_dtypes = []

    def where(self, *args):
        """
        Add filter expressions to the query.

        Parameters
        ----------
        *args : list
            Filter expressions to be added.
        Returns
        -------
        QueryBuilder
            The updated QueryBuilder instance.
        """
        if len(args) == 0:
            return self
        filtered_args = [arg for arg in args if arg is not None]
        self.filters.extend(filtered_args)
        return self

    def filter(self, *args):
        """
        Alias for where().

        Parameters
        ----------
        *args : list
            Filter expressions to be added.

        Returns
        -------
        QueryBuilder
            The updated QueryBuilder instance.
        """
        return self.where(*args)

    def havingTag(self, **kwargs):
        """
        Add tag-based filters to the query.

        Parameters
        ----------
        **kwargs : dict
            Tag-value pairs to filter by.

        Returns
        -------
        QueryBuilder
            The updated QueryBuilder instance.
        """
        for k, arg in kwargs.items():
            self.filters.append(TagSelector(k) == arg)
        return self

    def metric(self, name) -> MetricSelector:
        """
        Create a metric selector for the given name.

        Parameters
        ----------
        name : str
           Name of the metric.

        Returns
        -------
        MetricSelector
           Metric selector object.
        """
        return MetricSelector(name)

    def channel(self, **kwargs) -> TimeSeriesSelector:
        """
        Create a time series selector for the given channel tags.

        Parameters
        ----------
        **kwargs : dict
            Channel tag-value pairs.

        Returns
        -------
        TimeSeriesSelector
            Time series selector object.
        """
        expr = None
        for k, arg in kwargs.items():
            if not expr:
                expr = TagSelector(k) == str(arg)
            else:
                expr = expr & (TagSelector(k) == str(arg))
        return TimeSeriesSelector(expr)

    def select(self, *args) -> Self:
        """
        Set the selection expressions for the query.

        Parameters
        ----------
        *args : list
            Selection expressions.

        Returns
        -------
        QueryBuilder
            The updated QueryBuilder instance.
        """
        self.selections = list(args)
        return self

    def _determine_result_dtypes(self, default_dtype: T = T.DoubleType()):
        """
        Determine result data types for the selections by building each
        against an empty cache and inspecting the result's dtype.

        Parameters
        ----------
        default_dtype : pyspark.sql.types.DataType, optional
            Default data type to use if not specified (default is DoubleType).

        Returns
        -------
        list
            List of Spark data types for each selection.
        """
        result_dtypes = []
        for s in self.selections:
            result_object = s.build(EmptyTimeSeriesCache())
            dtype = default_dtype
            if hasattr(result_object, "dtype") and callable(result_object.dtype):
                dtype = result_object.dtype()
            elif hasattr(s, "dtype") and callable(s.dtype):
                dtype = s.dtype()
            result_dtypes.append(dtype)
        return result_dtypes

    def solve(self, spark, solver: QuerySolver = BlobSolver()) -> DataFrame:
        """
        Execute the query using the specified solver and return a Spark DataFrame.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        solver : QuerySolver, optional
            Query solver to use (default is BlobSolver).

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing query results.
        """
        self.result_dtypes = self._determine_result_dtypes()

        # create Query
        tags_df = solver.filter_container_tags(spark, self)
        metrics_df = solver.filter_container_metrics(spark, self, tags_df)
        channel_tags_df = solver.filter_channel_tags(spark, self, metrics_df)
        channel_metrics_df = solver.filter_channel_metrics(spark, self, channel_tags_df)

        return solver.solve(self, channel_metrics_df, self.selections, self.result_dtypes)

    def toPandas(self, spark, solver: QuerySolver = BlobSolver()) -> pd.DataFrame:
        """
        Execute the query and collect results into a Pandas DataFrame.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        solver : QuerySolver, optional
            Query solver to use (default is BlobSolver).

        Returns
        -------
        pd.DataFrame
            Pandas DataFrame containing query results.
        """
        df = self.solve(spark, solver)
        return df.toPandas()
