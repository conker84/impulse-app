from collections.abc import Iterable
from functools import partial

import pandas as pd
import pyspark.sql.functions as F
import pyspark.sql.types as T
from pyspark.sql import DataFrame

from mda_query_engine.analyze.metadata.metric_expression import MetricExpression
from mda_query_engine.analyze.metadata.tag_expression import TagExpression
from mda_query_engine.analyze.metadata.time_series_expression import TimeSeriesExpression
from mda_query_engine.model.series.sample_series import SampleSeries
from .query_solver import QuerySolver
from .series_cache import SeriesCache
from .utils.interval_encoder import IntervalEncoder


class DeltaTimeSeriesCache(SeriesCache):
    def __init__(self, pdf):
        """
        Initialize the DeltaTimeSeriesCache.

        Parameters
        ----------
        pdf : pd.DataFrame
            DataFrame containing time series data.
        """
        self.mdf = pdf.drop(columns=["tstart", "tend", "value"]).drop_duplicates().reset_index()
        self.pdf = pdf.sort_values(["container_id", "channel_id", "tstart"]).reset_index()

    def resolve(self, selection):
        """
        Resolve selected tags/metrics to a list of candidates.

        Parameters
        ----------
        selection : Any
            The selection object specifying tags or metrics.

        Returns
        -------
        pd.DataFrame
            DataFrame containing the resolved candidates.
        """
        idx = selection._expr.build_pandas(self.mdf)
        return self.mdf[idx]

    def load_blob(self, mid, cid):
        """
        Load a time series blob from the DataFrame.

        Parameters
        ----------
        mid : Any
            Container or measurement ID.
        cid : Any
            Channel ID.

        Returns
        -------
        SampleSeries
            The loaded sample series object.
        """
        s = self.pdf[(self.pdf.container_id == mid) & (self.pdf.channel_id == cid)]
        return SampleSeries(s.tstart, s.tend, s.value)


class DeltaSolver(QuerySolver):
    def __init__(self, spark, is_raw_data: bool = True, drop_implausible_data: bool = False):
        """
        Initialize the DeltaSolver.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        is_raw_data : bool
            Indicates whether the input data is raw point data (with a timestamp column) or already in RLE format
            (with tstart and tend columns).
        drop_implausible_data: bool
            Specifies whether we should drop implausible data points before RLE encoding.
            IMPORTANT: The silver layer needs the is_plausible column for this to work.
            If this is set to True, all data points which are marked as implausible will be dropped before RLE encoding.
        """
        super().__init__()
        self.spark = spark
        self.is_raw_data: bool = is_raw_data
        self.drop_im_plausible_data: bool = drop_implausible_data

        self.interval_encoder: IntervalEncoder = IntervalEncoder(
            timestamp_col_name="timestamp",
            drop_implausible_data_points=self.drop_im_plausible_data,
        )

    def filter_container_tags(self, spark, query) -> DataFrame:
        """
        Stage 1: Generate DataFrame filtered by container tags.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        query : QueryBuilder
            Query object containing filters and db info.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame filtered by container tags.
        """
        filters = []
        required_tags = []
        for filt in query.filters:
            if isinstance(filt, TagExpression):
                filters.append(filt)
                required_tags.extend(filt.required_tags())
        required_tags = set(required_tags)
        # read df
        tags = query.db.container_tags(spark)
        # apply filters
        if len(filters) > 0:
            # ToDo: In addition to filtering the key column, also filter for required values before pivoting
            tags = tags.where(F.col("key").isin(required_tags))
            tags = tags.groupBy("container_id")
            tags = tags.pivot("key", list(required_tags)).agg({"value": "first"})
            expr = self._build_expr(filters)
            tags = tags.where(expr)
            for tag in required_tags:
                tags = tags.withColumnRenamed(tag, f"mt_{tag}")
        else:
            tags = tags.select("container_id").distinct()
        return tags

    def filter_container_metrics(self, spark, query, container_df) -> DataFrame:
        """
        Stage 2: Filter containers by metrics.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        query : QueryBuilder
            Query object containing filters and db info.
        container_df : pyspark.sql.DataFrame
            DataFrame containing container information.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing filtered container IDs.
        """
        filters = []
        tag_count = 0
        for filt in query.filters:
            if isinstance(filt, MetricExpression):
                filters.append(filt)
            if isinstance(filt, TagExpression):
                tag_count += 1
        # apply filter
        metrics = query.db.container_metrics(spark)
        if len(filters) > 0:
            metrics = metrics.where(self._build_expr(filters))
        if tag_count > 0:
            return metrics.join(F.broadcast(container_df), on=["container_id"], how="inner")
        else:
            return metrics

    def filter_channel_tags(self, spark, query, container_df) -> DataFrame:
        """
        Stage 3: Filter channels by measurements and tags.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        query : QueryBuilder
            Query object containing filters and db info.
        container_df : pyspark.sql.DataFrame
            DataFrame containing container information.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing filtered channel tags.
        """
        mids = container_df.select("container_id").distinct()

        filters = []
        required_tags = []
        for selection in query.selections:
            if not isinstance(selection, TimeSeriesExpression):
                continue
            filters.append(selection)
            required_tags.extend(selection.required_tags())
        required_tags = set(required_tags)
        tbl = query.db.channel_tags(spark)
        expr = self._build_expr(filters)
        # filter by tags
        # ToDo: In addition to filtering the key column, also filter for required values before pivoting
        tags = (
            tbl.where(F.col("key").isin(required_tags))
            .join(F.broadcast(mids), on=["container_id"], how="inner")
            .groupBy("container_id", "channel_id")
            .pivot("key", list(required_tags))
            .agg(F.first(F.col("value")))
            .where(expr)
        )
        for tag in required_tags:
            tags = tags.withColumnRenamed(tag, f"ct_{tag}")
        return tags

    def filter_channel_metrics(self, spark, query, channel_df) -> DataFrame:
        """
        Stage 4: Filter channels by metrics.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        query : QueryBuilder
            Query object containing filters and db info.
        channel_df : pyspark.sql.DataFrame
            DataFrame containing channel information.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing filtered channel metrics.
        """
        # todo: filtering based on metric filters
        tbl = query.db.channel_metrics(spark)
        metrics = tbl.select("container_id", "channel_id", "sample_count").join(
            F.broadcast(channel_df),
            on=["container_id", "channel_id"],
            how="inner",
        )
        for col in ["sample_count"]:
            metrics = metrics.withColumnRenamed(col, f"cm_{col}")
        return metrics

    @staticmethod
    def _solve_udf(pdf, selections: Iterable = None):
        """
        UDF to solve for a single container by applying selections.

        Parameters
        ----------
        pdf : pd.DataFrame
            DataFrame containing time series data for a container.
        selections : Iterable, optional
            List of selection expressions to apply.

        Returns
        -------
        pd.DataFrame
            DataFrame containing results for each selection.
        """
        cache = DeltaTimeSeriesCache(pdf)
        result = {"container_id": [pdf.container_id.iloc[0]]}
        for s in selections:
            res = s.build(cache)
            if hasattr(res, "get_data") and callable(res.get_data):
                res = res.get_data()
            result[s._alias] = [res]
        return pd.DataFrame(result)

    def solve(self, query, channels_df, selections, dtypes):
        """
        Solve the query by grouping channels and applying selections.

        Parameters
        ----------
        query : QueryBuilder
            Query object containing database and filter information.
        channels_df : pyspark.sql.DataFrame
            DataFrame containing channel information.
        selections : list
            List of selection expressions to apply.
        dtypes : list
            List of data types for each selection.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing results for each container.
        """
        q = query.db.channels(self.spark)
        schema_entries = [T.StructField("container_id", T.LongType())]
        for s, dtype in zip(selections, dtypes, strict=False):
            schema_entries.append(T.StructField(s._alias, dtype))
        schema = T.StructType(schema_entries)

        if self.is_raw_data:
            # Calculate the tend info and prepare the data for the solving step.
            q = self.interval_encoder.prepare_channels_df(q)

        # ToDo: Optimize with collect channels_df and filter or leverage Photon bhjFilterPushdown
        df = q.join(F.broadcast(channels_df), on=["container_id", "channel_id"])
        res = df.groupBy("container_id").applyInPandas(
            partial(DeltaSolver._solve_udf, selections=selections), schema
        )
        return res
