from functools import partial

import pyspark.sql.functions as F
import pyspark.sql.types as T
from pyspark.sql import DataFrame

from mda_query_engine.analyze.metadata.metric_expression import MetricExpression
from mda_query_engine.analyze.metadata.time_series_expression import TimeSeriesExpression
from .basic_narrow_solver import BasicNarrowSolver
from .query_solver import QuerySolver
from .solver_config import SolverConfig
from .utils.interval_encoder import IntervalEncoder


class StlaNarrowSolver(QuerySolver):
    """Narrow-style metric-only solver for the STLA silver-layer schema.

    Differences from :class:`BasicNarrowSolver`:

    * Container id column is ``recording_session_id`` (string) instead of
      ``container_id`` (long).
    * Channels are keyed by a composite ``signal_name`` of the form
      ``"signal:frame:network"``; ``channel_metrics`` uses the 2-part
      ``signal_network`` (``"signal:network"``) as its key. ``signal_network``
      is virtual in ``channels`` and is derived at query time from
      ``signal_name``.
    * ``channels`` is raw (no RLE): ``time`` (double) is the sample instant;
      ``value_double`` is the numeric value. ``tend`` is derived via
      :class:`IntervalEncoder`. There is no ``is_plausible`` column.

    Columns are normalized to the canonical names ``container_id``,
    ``channel_id``, ``tstart``, ``tend``, ``value`` before the UDF so that
    :class:`BasicNarrowTimeSeriesCache` and
    :meth:`TimeSeriesSelector.build` (which hardcodes ``container_id`` /
    ``channel_id``) can be reused unchanged.
    """

    def __init__(self, spark, config: SolverConfig = None):
        """Initialize the StlaNarrowSolver.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        config : SolverConfig, optional
            Solver configuration. Defaults to a standard :class:`SolverConfig`
            with canonical column names — columns from the STLA layer are
            renamed to these canonical names inside each stage.
        """
        super().__init__(config)
        self.spark = spark
        self.interval_encoder: IntervalEncoder = IntervalEncoder(
            timestamp_col_name="time",
            drop_implausible_data_points=False,
        )

    @staticmethod
    def _derive_channel_id(signal_name_col: str = "signal_name") -> F.Column:
        """Derive the 2-part ``signal_network`` id from the 3-part ``signal_name``.

        ``signal_name`` has the format ``"{signal}:{frame}:{network}"``. The
        channel id used for joins with ``channel_metrics`` is
        ``"{signal}:{network}"`` (the middle ``frame`` component is dropped).

        Uses :func:`pyspark.sql.functions.get` for bounds-tolerant indexing so
        that malformed (2-part or empty) signal names yield a NULL for the
        missing component; :func:`pyspark.sql.functions.concat_ws` skips NULL
        inputs, so a 2-part name like ``LOG_LEVEL:LOG`` collapses to
        ``LOG_LEVEL``.
        """
        parts = F.split(F.col(signal_name_col), ":")
        return F.concat_ws(":", F.get(parts, F.lit(0)), F.get(parts, F.lit(2)))

    def filter_container_tags(self, spark, query) -> DataFrame:
        """Return an empty DataFrame — this solver does not filter by tags."""
        return spark.createDataFrame([], schema=T.StructType([]))

    def filter_container_metrics(
        self, spark, query, container_df, pre_filtered_containers_df=None
    ) -> DataFrame:
        """Filter containers by metrics and canonicalize the id column.

        Renames ``recording_session_id`` → ``container_id`` up front so that
        downstream stages and the UDF can use canonical names. Applies any
        :class:`MetricExpression` filters and dedups on ``container_id``.
        """
        filters = [f for f in query.filters if isinstance(f, MetricExpression)]
        if pre_filtered_containers_df is not None:
            metrics = pre_filtered_containers_df
        else:
            metrics = query.db.container_metrics(self.spark)
        metrics = metrics.withColumnRenamed("recording_session_id", "container_id")
        if len(filters) > 0:
            expr = self._build_expr(filters)
            return metrics.where(expr).dropDuplicates([self.config.container_id_col])
        return metrics.dropDuplicates([self.config.container_id_col])

    def filter_channel_tags(self, spark, query, container_df) -> DataFrame:
        """Pass through the container DataFrame — no channel-tag filtering."""
        return container_df

    def filter_channel_metrics(self, spark, query, container_df) -> DataFrame:
        """Filter channels by metric predicates and tag-like columns.

        In STLA, ``signal`` / ``network`` live as columns on
        ``channel_metrics`` (not in an EAV table), so predicates from
        ``channel(signal=..., network=...)`` resolve directly as column
        filters. Required tag columns are renamed with a ``ct_`` prefix;
        ``signal_network`` is renamed to the canonical ``channel_id``;
        ``recording_session_id`` is renamed to ``container_id``.
        """
        channel_metrics_df = query.db.channel_metrics(spark)
        filters = []
        required_tags = []
        for selection in query.selections:
            if not isinstance(selection, TimeSeriesExpression):
                continue
            filters.append(selection)
            required_tags.extend(selection.required_tags())
        required_tags = set(required_tags)
        if len(filters) > 0:
            expr = self._build_expr(filters)
            channel_metrics_df = channel_metrics_df.where(expr)
        channel_metrics_df = channel_metrics_df.withColumnRenamed(
            "recording_session_id", self.config.container_id_col
        ).withColumnRenamed("signal_network", self.config.channel_id_col)
        result = channel_metrics_df.join(
            F.broadcast(container_df.select(self.config.container_id_col)),
            on=[self.config.container_id_col],
            how="inner",
        )
        for tag in required_tags:
            result = result.withColumnRenamed(tag, f"ct_{tag}")
        return result.select(
            self.config.container_id_col,
            self.config.channel_id_col,
            *[f"ct_{tag}" for tag in required_tags],
        )

    def solve(self, query, channels_df, selections, dtypes) -> DataFrame:
        """Load raw STLA channels, derive ``signal_network``, and evaluate selections per container."""
        col_map = self.config.col_map

        q = query.db.channels(self.spark)
        # Project to exactly the columns the UDF needs, canonicalizing names.
        # The STLA channels table carries extra columns in practice
        # (provider, runid, tcid, dt, input_file_name, history) which must
        # not leak into the UDF.
        q = q.select(
            F.col("recording_session_id").alias(self.config.container_id_col),
            self._derive_channel_id("signal_name").alias(self.config.channel_id_col),
            F.col("time"),
            F.col("value_double").alias(self.config.value_col),
        )
        # Derive tend via LEAD and rename "time" → "tstart".
        q = self.interval_encoder.prepare_channels_df(q)

        schema_entries = [T.StructField(self.config.container_id_col, T.StringType())]
        for s, dtype in zip(selections, dtypes, strict=False):
            schema_entries.append(T.StructField(s._alias, dtype))
        schema = T.StructType(schema_entries)

        solve_udf = F.pandas_udf(
            partial(BasicNarrowSolver._solve_udf, selections=selections, col_map=col_map),
            schema,
            F.PandasUDFType.GROUPED_MAP,
        )
        df = q.join(
            F.broadcast(channels_df),
            on=[self.config.container_id_col, self.config.channel_id_col],
        )

        container_count = channels_df.select(self.config.container_id_col).distinct().count()
        if container_count == 0:
            return self.spark.createDataFrame([], schema=schema)
        return (
            df.repartition(container_count, self.config.container_id_col)
            .groupBy(self.config.container_id_col)
            .apply(solve_udf)
        )
