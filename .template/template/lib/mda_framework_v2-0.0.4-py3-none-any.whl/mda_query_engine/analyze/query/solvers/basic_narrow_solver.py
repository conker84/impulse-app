from functools import partial
from collections.abc import Iterable

import pandas as pd
import pyspark.sql.functions as F
import pyspark.sql.types as T
from pyspark.sql import DataFrame

from mda_query_engine.analyze.metadata.metric_expression import MetricExpression
from mda_query_engine.analyze.metadata.time_series_expression import TimeSeriesExpression
from mda_query_engine.model.series.sample_series import SampleSeries
from .query_solver import QuerySolver
from .series_cache import SeriesCache
from .utils.interval_encoder import IntervalEncoder


# ToDo Introduce a default config and allow to overwrite it with a config file
# ToDo Remove all the hardcoded stuff and use the config file
class BasicNarrowTimeSeriesCache(SeriesCache):
    def __init__(self, pdf):
        """
        Initialize the BasicNarrowTimeSeriesCache.

        Parameters
        ----------
        pdf : pd.DataFrame #todo double check really pd ??
            DataFrame containing time series data.
        """
        self.mdf = pdf.drop(columns=["tstart", "tend", "value"]).drop_duplicates().reset_index()
        self.pdf = pdf.sort_values(["container_id", "channel_id", "tstart"]).reset_index()

    def resolve(self, selection):
        """
        Resolve selected tags/metrics to a list of candidates.

        Parameters
        ----------
        selection : Any
            The selection object specifying tags or metrics.

        Returns
        -------
        pd.DataFrame
            DataFrame containing the resolved candidates.
        """
        idx = selection._expr.build_pandas(self.mdf)
        return self.mdf[idx]

    def load_blob(self, mid, cid):
        """
        Load a time series blob from the DataFrame.

        Parameters
        ----------
        mid : Any
            Container or measurement ID.
        cid : Any
            Channel ID.

        Returns
        -------
        SampleSeries
            The loaded sample series object.
        """
        s = self.pdf[(self.pdf.container_id == mid) & (self.pdf.channel_id == cid)]
        return SampleSeries(s.tstart, s.tend, s.value)


class BasicNarrowSolver(QuerySolver):
    def __init__(self, spark, is_raw_data: bool = False, drop_im_plausible_data: bool = False):
        """
        Initialize the BasicNarrowSolver.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        is_raw_data : bool
            Indicates whether the input data is raw point data (with a timestamp column) or already in RLE format
            (with tstart and tend columns).
        drop_im_plausible_data: bool
            Specifies whether we should drop implausible data points before RLE encoding.
            IMPORTANT: The silver layer needs the is_plausible column for this to work.
            If this is set to True, all data points which are marked as implausible will be dropped before RLE encoding.
        """
        super().__init__()
        self.spark = spark
        self.is_raw_data: bool = is_raw_data
        self.drop_im_plausible_data: bool = drop_im_plausible_data

        self.interval_encoder: IntervalEncoder = IntervalEncoder(
            timestamp_col_name="timestamp",
            drop_implausible_data_points=self.drop_im_plausible_data,
        )

    @staticmethod
    def _solve_udf(pdf, selections: Iterable = None) -> pd.DataFrame:
        """
        UDF to solve for a single container by applying selections.

        Parameters
        ----------
        pdf : pd.DataFrame
            DataFrame containing time series data for a container.
        selections : Iterable, optional
            List of selection expressions to apply.

        Returns
        -------
        pd.DataFrame
            DataFrame containing results for each selection.
        """
        cache = BasicNarrowTimeSeriesCache(pdf)
        result = {"container_id": [pdf.container_id.iloc[0]]}
        for s in selections:
            res = s.build(cache)
            if hasattr(res, "get_data") and callable(res.get_data):
                res = res.get_data()
            result[s._alias] = [res]
        return pd.DataFrame(result)

    def filter_container_tags(self, spark, query) -> DataFrame:
        """
        Generate DataFrame filtered by container tags.

        The BasicNarrowSolver does not filter by container tags,
        so it returns an empty DataFrame.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        query : QueryBuilder
            Query object containing filters and db info.

        Returns
        -------
        pyspark.sql.DataFrame
            Empty DataFrame.
        """
        return spark.createDataFrame([], schema=T.StructType([]))

    def filter_container_metrics(self, spark, query, container_df) -> DataFrame:
        """
        Filter containers by metrics.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        query : QueryBuilder
            Query object containing filters and db info.
        container_df : pyspark.sql.DataFrame
            DataFrame containing container information.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing filtered container IDs.
        """
        filters = []
        for filt in query.filters:
            if isinstance(filt, MetricExpression):
                filters.append(filt)
        # apply filter
        metrics = query.db.container_metrics(self.spark)
        if len(filters) > 0:
            expr = self._build_expr(filters)
            return metrics.where(expr)

        return metrics

    def filter_channel_tags(self, spark, query, container_df) -> DataFrame:
        """
        Pass through container DataFrame.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        query : QueryBuilder
            Query object containing filters and db info.
        container_df : pyspark.sql.DataFrame
            DataFrame containing container information.

        Returns
        -------
        pyspark.sql.DataFrame
            The input container DataFrame.
        """
        return container_df

    def filter_channel_metrics(self, spark, query, container_df) -> DataFrame:
        """
        Filter channels by metrics and required tags.

        Parameters
        ----------
        spark : SparkSession
            Spark session used for query execution.
        query : QueryBuilder
            Query object containing filters and db info.
        container_df : pyspark.sql.DataFrame
            DataFrame containing container information.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing filtered channel information.
        """
        channel_metrics_df = query.db.channel_metrics(spark)
        filters = []
        required_tags = []
        for selection in query.selections:
            if not isinstance(selection, TimeSeriesExpression):
                continue
            filters.append(selection)
            required_tags.extend(selection.required_tags())
        required_tags = set(required_tags)
        expr = self._build_expr(filters)
        if len(filters) > 0:
            channel_metrics_df = channel_metrics_df.where(expr)
        result = channel_metrics_df.join(
            F.broadcast(container_df.select("container_id").distinct()),
            on=["container_id"],
            how="inner",
        )
        # ToDo Determine a selector id for every selection and add it to the result rather than using the tags
        for tag in required_tags:
            result = result.withColumnRenamed(tag, f"ct_{tag}")
        return result.select("container_id", "channel_id", *[f"ct_{tag}" for tag in required_tags])

    def solve(self, query, channels_df, selections, dtypes) -> DataFrame:
        """
        Solve the query by grouping channels and applying selections.

        Parameters
        ----------
        query : QueryBuilder
            Query object containing database and filter information.
        channels_df : pyspark.sql.DataFrame
            DataFrame containing channel information.
        selections : list
            List of selection expressions to apply.
        dtypes : list
            List of data types for each selection.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing results for each container.
        """
        q = query.db.channels(self.spark)
        schema_entries = [T.StructField("container_id", T.LongType())]
        for s, dtype in zip(selections, dtypes, strict=False):
            schema_entries.append(T.StructField(s._alias, dtype))
        schema = T.StructType(schema_entries)

        if self.is_raw_data:
            # Calculate the tend info and prepare the data for the solving step.
            q = self.interval_encoder.prepare_channels_df(q)

        df = q.join(F.broadcast(channels_df), on=["container_id", "channel_id"])
        res = df.groupBy("container_id").applyInPandas(
            partial(BasicNarrowSolver._solve_udf, selections=selections), schema
        )
        return res
