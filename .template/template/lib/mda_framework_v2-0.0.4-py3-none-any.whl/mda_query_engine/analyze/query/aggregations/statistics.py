from __future__ import annotations

import numpy as np
import pyspark.sql.types as T

from mda_query_engine.analyze.metadata.tag_expression import TagExpression
from mda_query_engine.analyze.metadata.time_series_expression import TimeSeriesExpression
from mda_query_engine.analyze.query.solvers.series_cache import SeriesCache
from mda_query_engine.model.series.sample_series import SampleSeries
from mda_query_engine.model.series.intervals import Intervals
from .aggregation import Aggregation

# Supported statistics
SUPPORTED_STATISTICS = {"min", "max", "mean", "median"}


class StatisticsAggregator(Aggregation):
    """Statistics aggregation for multiple time series expressions."""

    def __init__(
        self,
        selections: list[TimeSeriesExpression],
        statistics: list[str],
        event_expression: TimeSeriesExpression | None = None,
    ):
        """
        Initialize a StatisticsAggregator.

        Parameters
        ----------
        selections : list of TimeSeriesExpression
            Time series expressions to calculate statistics for.
        statistics : list of str
            List of statistics to compute. Supported values: "min", "max", "mean", "median".
        event_expression : TimeSeriesExpression, optional
            Optional event expression to restrict statistics calculation to event intervals.
            When evaluated, this should produce an Intervals object.

        Raises
        ------
        ValueError
            If no selections are provided or if unsupported statistics are requested.
        """
        if not selections:
            raise ValueError("At least one selection must be provided")

        invalid_stats = set(statistics) - SUPPORTED_STATISTICS
        if invalid_stats:
            raise ValueError(
                f"Unsupported statistics: {invalid_stats}. "
                f"Supported statistics are: {SUPPORTED_STATISTICS}"
            )

        if not statistics:
            raise ValueError("At least one statistic must be requested")

        self.selections = selections
        self.statistics = statistics
        self.event_expression = event_expression

    def __str__(self) -> str:
        """
        Return a string representation of the StatisticsAggregator object.

        Returns
        -------
        str
            String representation of the StatisticsAggregator object.
        """
        selections_str = ", ".join(str(s) for s in self.selections)
        event_str = f", event_expression={self.event_expression}" if self.event_expression else ""
        return (
            f"<StatisticsAggregator selections=[{selections_str}], "
            f"statistics={self.statistics}{event_str}>"
        )

    def dtype(self) -> T.StructType:
        """
        Return the data type of the aggregation result.

        Returns
        -------
        pyspark.sql.types.StructType
            Data type of the aggregation result.

        Notes
        -----
        The schema structure:
        - event_timestamps: list of [start, end] pairs for each event
        - numeric_values: list (per expression) of list (per event) of maps with statistics
        - string_values: list (per expression) of list (per event) of maps (empty for now)
        """
        return T.StructType(
            [
                T.StructField(
                    "event_timestamps",
                    T.ArrayType(T.ArrayType(T.DoubleType())),
                    nullable=True,
                ),
                T.StructField(
                    "numeric_values",
                    T.ArrayType(T.ArrayType(T.MapType(T.StringType(), T.DoubleType()))),
                    nullable=True,
                ),
                T.StructField(
                    "string_values",
                    T.ArrayType(T.ArrayType(T.MapType(T.StringType(), T.StringType()))),
                    nullable=True,
                ),
            ]
        )

    @staticmethod
    def _extract_interval_data(
        series: SampleSeries, tstart: float, tend: float
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Extract values and durations from a pre-filtered SampleSeries for a specific interval.

        Parameters
        ----------
        series : SampleSeries
            Pre-filtered series (already filtered with .where(intervals))
        tstart : float
            Start time of the current interval
        tend : float
            End time of the current interval

        Returns
        -------
        tuple of (values, durations)
            Numpy arrays of values and their durations within the interval
        """
        if len(series) == 0:
            return np.array([]), np.array([])

        # Find indices where samples overlap with [tstart, tend]
        mask = (series.tends > tstart) & (series.tstarts < tend)

        if not np.any(mask):
            return np.array([]), np.array([])

        # Extract matching samples
        values = series.values[mask]

        # Calculate actual durations (clipped to interval bounds)
        starts = np.maximum(series.tstarts[mask], tstart)
        ends = np.minimum(series.tends[mask], tend)
        durations = ends - starts

        return values, durations

    @staticmethod
    def _weighted_median(values: np.ndarray, weights: np.ndarray) -> float:
        """
        Calculate the weighted median of values.

        Parameters
        ----------
        values : np.ndarray
            Array of values (NaN values will be filtered out)
        weights : np.ndarray
            Array of weights corresponding to each value

        Returns
        -------
        float
            The weighted median value
        """
        # Filter out NaN values
        valid_mask = ~np.isnan(values)
        valid_values = values[valid_mask]
        valid_weights = weights[valid_mask]

        if len(valid_values) == 0:
            return np.nan

        # Sort values and weights together by value
        sorted_indices = np.argsort(valid_values)
        sorted_values = valid_values[sorted_indices]
        sorted_weights = valid_weights[sorted_indices]

        # Calculate cumulative weights
        cumulative_weights = np.cumsum(sorted_weights)
        total_weight = cumulative_weights[-1]

        if total_weight == 0:
            return np.nan

        # Find the index where cumulative weight reaches 50% of total
        half_weight = total_weight / 2
        median_idx = np.searchsorted(cumulative_weights, half_weight)

        # Handle edge case where median_idx is at the end
        if median_idx >= len(sorted_values):
            median_idx = len(sorted_values) - 1

        return float(sorted_values[median_idx])

    @staticmethod
    def _calculate_statistics(
        values: np.ndarray, durations: np.ndarray, statistics: list[str]
    ) -> dict[str, float]:
        """
        Calculate requested statistics for the given values and durations.

        Parameters
        ----------
        values : np.ndarray
            Array of sample values
        durations : np.ndarray
            Array of sample durations (for weighted calculations)
        statistics : list of str
            List of statistics to calculate

        Returns
        -------
        dict
            Dictionary mapping statistic names to their computed values
        """
        result = {}

        if len(values) == 0:
            for stat in statistics:
                result[stat] = np.nan
            return result

        for stat in statistics:
            if stat == "min":
                result[stat] = float(np.nanmin(values))
            elif stat == "max":
                result[stat] = float(np.nanmax(values))
            elif stat == "mean":
                # Duration-weighted mean
                total_duration = np.nansum(durations)
                if total_duration > 0:
                    result[stat] = float(np.nansum(values * durations) / total_duration)
                else:
                    result[stat] = np.nan
            elif stat == "median":
                # Duration-weighted median
                result[stat] = StatisticsAggregator._weighted_median(values, durations)

        return result

    def build(
        self, cache: SeriesCache
    ) -> tuple[list[list[float]], list[list[dict[str, float]]], list[list[dict[str, str]]]]:
        """
        Build the statistics for all selections across all event intervals.

        Parameters
        ----------
        cache : SeriesCache
            Cache containing time series data.

        Returns
        -------
        tuple
            A tuple containing:
            - event_timestamps: list of [start, end] pairs for each event
            - numeric_values: list (per expression) of list (per event) of dicts with statistics
            - string_values: list (per expression) of list (per event) of dicts (empty for now)
        """
        # Build all selections to SampleSeries
        built_series = [selection.build(cache) for selection in self.selections]

        # Determine intervals
        if self.event_expression is not None:
            # Build event expression to get Intervals
            intervals: Intervals = self.event_expression.build(cache)
            event_timestamps = intervals.get_data()

            # Pre-filter all SampleSeries once with the full intervals
            filtered_series = [series.where(intervals) for series in built_series]
        else:
            # Create a single interval covering the entire series
            # Find min start and max end across all series
            start_times = [series.start_time() for series in built_series if len(series) > 0]
            end_times = [series.end_time() for series in built_series if len(series) > 0]

            if start_times and end_times:
                min_start = min(t for t in start_times if not np.isnan(t))
                max_end = max(t for t in end_times if not np.isnan(t))
                event_timestamps = [[min_start, max_end]]
            else:
                # All series are empty
                event_timestamps = []

            # No pre-filtering needed when there's no event expression
            filtered_series = built_series

        # Calculate statistics for each event and each series
        numeric_values: list[list[dict[str, float]]] = []
        string_values: list[list[dict[str, str]]] = []

        for series in filtered_series:
            series_numeric_stats: list[dict[str, float]] = []
            series_string_stats: list[dict[str, str]] = []

            for event in event_timestamps:
                tstart, tend = event[0], event[1]

                # Extract data for this specific interval from the pre-filtered series
                values, durations = StatisticsAggregator._extract_interval_data(
                    series, tstart, tend
                )

                # Calculate requested statistics
                stats = StatisticsAggregator._calculate_statistics(
                    values, durations, self.statistics
                )
                series_numeric_stats.append(stats)

                # String values are empty for now
                series_string_stats.append({})

            numeric_values.append(series_numeric_stats)
            string_values.append(series_string_stats)

        return event_timestamps, numeric_values, string_values

    def required_tags(self) -> set[str]:
        """
        Return the set of required tags for all selections and event expression.

        Returns
        -------
        set of str
            Set of required tags for the aggregation.
        """
        tags: set[str] = set()
        for selection in self.selections:
            tags = tags.union(selection.required_tags())
        if self.event_expression is not None:
            tags = tags.union(self.event_expression.required_tags())
        return tags

    def get_selector_expr(self):
        """
        Return the selector expression for the aggregation.

        Returns
        -------
        Any
            Selector expression for the aggregation.
        """
        expr = None
        for selection in self.selections:
            selector_expr = selection.get_selector_expr()
            if expr is None:
                expr = selector_expr
            else:
                expr = expr | selector_expr

        if self.event_expression is not None:
            event_selector = self.event_expression.get_selector_expr()
            if expr is None:
                expr = event_selector
            else:
                expr = expr | event_selector

        return expr

    def get_required_tag_exprs(self) -> set[TagExpression]:
        """
        Return the set of required tag expressions for the aggregation.

        Returns
        -------
        set of TagExpression
            Set of required tag expressions for the aggregation.
        """
        tag_exprs: set[TagExpression] = set()
        for selection in self.selections:
            tag_exprs = tag_exprs.union(selection.get_required_tag_exprs())
        if self.event_expression is not None:
            tag_exprs = tag_exprs.union(self.event_expression.get_required_tag_exprs())
        return tag_exprs
