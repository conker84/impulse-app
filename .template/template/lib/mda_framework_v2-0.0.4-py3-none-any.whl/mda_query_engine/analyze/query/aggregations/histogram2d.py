import numpy as np
import pyspark.sql.types as T

from mda_query_engine.analyze.metadata.tag_expression import TagExpression
from .aggregation import Aggregation
from ..solvers.series_cache import SeriesCache
from ...metadata.time_series_expression import TimeSeriesExpression


class Histogram2D(Aggregation):
    """2D Histogram aggregation."""

    def __init__(
        self,
        x_selection: TimeSeriesExpression,
        y_selection: TimeSeriesExpression,
        x_bins: list[float],
        y_bins: list[float],
    ):
        """
        Initialize a Histogram2D aggregation.

        Parameters
        ----------
        x_selection : TimeSeriesExpression
            Time series expression for the x-axis.
        y_selection : TimeSeriesExpression
            Time series expression for the y-axis.
        x_bins : list of float
            Bin edges for the x-axis.
        y_bins : list of float
            Bin edges for the y-axis.
        """

        self.x_selection = x_selection
        self.y_selection = y_selection
        self.x_bins = x_bins
        self.y_bins = y_bins

    def __str__(self):
        """
        Return a string representation of the Histogram2D object.
        Returns
        -------
        str
            String representation of the Histogram2D object.
        """
        return (
            f"<Histogram2D x_selection={self.x_selection}, y_selection={self.y_selection}, x_bins={self.x_bins}, "
            f"y_bins={self.y_bins}>"
        )

    def dtype(self) -> T.StructType:
        """
        Return the data type of the aggregation result.
        Returns
        -------
        pyspark.sql.types.StructType
            Data type of the aggregation result.
        """
        return T.StructType(
            [
                T.StructField("H", T.ArrayType(T.ArrayType(T.DoubleType()))),
                T.StructField("xedges", T.ArrayType(T.DoubleType())),
                T.StructField("yedges", T.ArrayType(T.DoubleType())),
            ]
        )

    def build(self, cache: SeriesCache) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Build the bi-dimensional histogram of the two time series.

        Parameters
        ----------
        cache : SeriesCache
            Cache containing time series data.
        Returns
        -------
        hist2d : np.ndarray
            2D histogram array.
        x_edges : np.ndarray
            Bin edges for the x-axis.
        y_edges : np.ndarray
            Bin edges for the y-axis.
        """
        x_ts = self.x_selection.build(cache)
        y_ts = self.y_selection.build(cache)
        hist2d, x_edges, y_edges = x_ts.histogram2d(y_ts, x_bins=self.x_bins, y_bins=self.y_bins)
        return hist2d, x_edges, y_edges

    def required_tags(self) -> set[str]:
        """
        Return the set of required tags for both time series.

        Returns
        -------
        set of str
            Set of required tags for the aggregation.
        """
        return self.x_selection.required_tags().union(self.y_selection.required_tags())

    def get_selector_expr(self):
        """
        Return the selector expression for the aggregation.

        Returns
        -------
        Any
            Selector expression for the aggregation.
        """
        x_selector_expr = self.x_selection.get_selector_expr()
        y_selector_expr = self.y_selection.get_selector_expr()
        return x_selector_expr | y_selector_expr

    def get_required_tag_exprs(self) -> set[TagExpression]:
        """
        Return the set of required tag expressions for the aggregation.

        Returns
        -------
        set of TagExpression
            Set of required tag expressions for the aggregation.
        """
        return self.x_selection.get_required_tag_exprs().union(
            self.y_selection.get_required_tag_exprs()
        )
