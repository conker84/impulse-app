from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

import pyspark.sql.functions as f
from pyspark.sql import Column
from pyspark.sql.types import IntegerType

from mda_query_engine.analyze.metadata.metric_expression import MetricOp
from mda_query_engine.analyze.query.query_builder import QueryBuilder
from mda_reporting.aggregations.aggregation import Aggregation
from mda_reporting.config.config_parser import UnitUnderTest
from mda_reporting.events.event import Event

if TYPE_CHECKING:
    from mda_reporting.events.basic_event import BasicEvent
    from mda_reporting.events.container_event import ContainerEvent


class ReportEntityUtil:
    """Utility class for report entities."""

    @staticmethod
    def get_event_instance_id_column(
        event_type: type[BasicEvent] | type[ContainerEvent] = None,
        container_id_col: str = "container_id",
        event_name_col: str = "event_name",
        start_ts_col: str = "start_ts",
        end_ts_col: str = "end_ts",
    ) -> Column:
        """
        Generate a Spark column expression for event_instance_id.

        For BasicEvent, the event_instance_id is calculated as:
        crc32(container_id::event_name::start_ts::end_ts)

        For ContainerEvent, returns -1 as there is only one event instance per container.

        Parameters
        ----------
        event_type : type[BasicEvent] or type[ContainerEvent]
            The type of event (BasicEvent or ContainerEvent class)
        container_id_col : str
            Name of the container_id column
        event_name_col : str
            Name of the event_name column
        start_ts_col : str
            Name of the start timestamp column
        end_ts_col : str
            Name of the end timestamp column

        Returns
        -------
        pyspark.sql.Column
            Column expression for event_instance_id
        """

        from mda_reporting.events.basic_event import BasicEvent
        from mda_reporting.events.container_event import ContainerEvent

        if event_type is ContainerEvent:
            return f.lit(-1)

        return f.crc32(
            f.concat_ws(
                "::",
                f.col(container_id_col),
                f.col(event_name_col),
                f.col(start_ts_col),
                f.col(end_ts_col),
            )
        )

    @staticmethod
    def get_event_id_column(
        elements: list[Aggregation] | list[Event], element_name: str
    ) -> Column:
        """
        Generates a Spark SQL expression that maps event or aggregation names to their corresponding IDs.

        Parameters
        ----------
        elements : list of Aggregation or list of Event
            List of Aggregation or Event objects to map from.
        element_name : str
            The name of the column containing event or aggregation names.

        Returns
        -------
        pyspark.sql.Column
            A Spark SQL Column expression mapping names to IDs, or None if no match is found.
        """

        name_to_id = ReportEntityUtil._get_name_to_id_mapping(elements)
        col_expr = None
        for name, event_id in name_to_id.items():
            if event_id is None:
                continue
            elif col_expr is None:
                col_expr = f.when(f.col(element_name) == f.lit(name), f.lit(event_id))
            else:
                col_expr = col_expr.when(f.col(element_name) == f.lit(name), f.lit(event_id))

        return (
            col_expr.otherwise(None) if col_expr is not None else f.lit(None).cast(IntegerType())
        )

    @staticmethod
    def _get_name_to_id_mapping(elements: list[Aggregation] | list[Event]) -> dict:
        """
        Creates a mapping from names to IDs for a given list of Aggregation or Event objects.

        Parameters
        ----------
        elements : list of Aggregation or list of Event
            List of Aggregation or Event objects to map from.

        Returns
        -------
        dict
            Dictionary mapping each object's name to its ID.
        """
        if all(isinstance(x, Aggregation) for x in elements):
            name_to_id = {}
            for hist in elements:
                if hist and hist.get_event():
                    name_to_id[hist.get_name()] = hist.get_event().get_id()

        elif all(isinstance(x, Event) for x in elements):
            name_to_id = {
                element.get_name(): element.get_id() if element else None for element in elements
            }
        else:
            raise TypeError("elements must be a list of Aggregation or Event objects")

        return name_to_id

    @staticmethod
    def generate_uut_filter(
        query: QueryBuilder, units_under_test: list[UnitUnderTest]
    ) -> MetricOp:
        """
        Generates a filter condition for the given units under test, so only relevant units are considered.

        Parameters
        ----------
        query : QueryBuilder
            The query builder instance to create metric expressions.

        units_under_test : list of UnitUnderTest
            List of units under test to filter by. Each unit should have a unique identifier and start timestamp.
        Returns
        -------
        MetricOp
            A filter condition that can be applied to the query to restrict results to the specified units under test.
        """

        filter_condition: MetricOp | None = None

        for unit in units_under_test:
            vehicle_id_metric = query.metric(unit.uut_name.col_name)
            start_ts_metric = query.metric(unit.start_ts.col_name)

            if unit.end_ts:
                end_ts_metric = query.metric(unit.end_ts.col_name)

                unit_filter: MetricOp = (
                    (vehicle_id_metric == unit.uut_name.value)
                    & (start_ts_metric >= datetime.fromisoformat(unit.start_ts.value))
                    & (end_ts_metric <= datetime.fromisoformat(unit.end_ts.value))
                )

            else:
                unit_filter: MetricOp = (vehicle_id_metric == unit.uut_name.value) & (
                    start_ts_metric >= datetime.fromisoformat(unit.start_ts.value)
                )

            filter_condition = filter_condition | unit_filter if filter_condition else unit_filter
        return filter_condition
