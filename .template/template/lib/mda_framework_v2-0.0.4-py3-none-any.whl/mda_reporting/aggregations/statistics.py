from __future__ import annotations

import zlib
from collections.abc import Callable

import pyspark.sql.functions as f
from pyspark.sql import SparkSession, Row, DataFrame
from pyspark.sql.types import IntegerType

from mda_query_engine.analyze.metadata.time_series_expression import TimeSeriesExpression
from mda_query_engine.analyze.query.aggregations.statistics import (
    StatisticsAggregator as QueryEngineStatisticsAggregator,
    SUPPORTED_STATISTICS,
)
from mda_query_engine.analyze.query.query_builder import QueryBuilder
from mda_query_engine.analyze.query.solvers.query_solver import QuerySolver
from mda_reporting.aggregations.aggregation import Aggregation
from mda_reporting.events.basic_event import BasicEvent
from mda_reporting.events.event import Event
from mda_reporting.persist.dimension_schema import STATISTICS_DIMENSION_SCHEMA
from mda_reporting.persist.fact_schema import STATISTICS_FACT_SCHEMA
from mda_reporting.util.report_entity_util import ReportEntityUtil


class Statistics(Aggregation):
    """Class representing a statistics aggregation in a report."""

    def __init__(
        self,
        name: str,
        selections: list[TimeSeriesExpression],
        aggregation_labels: list[str],
        event: Event,
        desc: str = None,
        signal_names: list[str] | None = None,
    ):
        """
        Initialize a Statistics object.

        Parameters
        ----------
        name : str
            Name of the statistics aggregation.
        selections : list of TimeSeriesExpression
            Time series expressions to calculate statistics for.
        aggregation_labels : list of str
            List of statistics to compute (e.g., ["min", "max", "mean", "median"]).
        event : Event
            Event to filter the expressions.
        desc : str, optional
            Description of the statistics aggregation.
        signal_names : list of str, optional
            Optional display names for each selection expression.
            If not provided, string representations of expressions are used.

        Raises
        ------
        ValueError
            If unsupported statistics are requested.
        """
        invalid_stats = set(aggregation_labels) - SUPPORTED_STATISTICS
        if invalid_stats:
            raise ValueError(
                f"Unsupported statistics: {invalid_stats}. "
                f"Supported statistics are: {SUPPORTED_STATISTICS}"
            )

        Aggregation.__init__(self, name)
        self.selections = selections
        self.aggregation_labels = aggregation_labels
        self.event = event
        self.desc = desc
        self.signal_names = signal_names or [str(s) for s in selections]
        self.expression = self._set_expression()

    def get_id(self) -> int:
        """
        Returns a unique identifier for the statistics aggregation.

        Returns
        -------
        int
            Unique identifier for the statistics aggregation.
        """
        hash_input = f"{self.name}::{self.get_expression_str()}"
        return zlib.crc32(hash_input.encode()) & 0x7FFFFFFF  # Ensures positive 32-bit int

    def get_event(self) -> Event:
        """
        Get the event associated with the statistics aggregation.

        Returns
        -------
        Event
            The event associated with the statistics aggregation.
        """
        return self.event

    def _set_expression(self) -> QueryEngineStatisticsAggregator:
        """
        Create the query engine StatisticsAggregator with the appropriate configuration.

        Returns
        -------
        QueryEngineStatisticsAggregator
            The statistics aggregator from the query engine.
        """
        return QueryEngineStatisticsAggregator(
            selections=self.selections,
            statistics=self.aggregation_labels,
            event_expression=self.event.get_expression(),
        ).alias(self.name)

    def get_expression(self) -> QueryEngineStatisticsAggregator:
        """
        Get the query engine expression for the statistics aggregation.

        Returns
        -------
        QueryEngineStatisticsAggregator
            The statistics aggregator expression.
        """
        return self.expression

    def get_expression_str(self) -> str:
        """
        Get a string representation of the statistics aggregation expression.

        Returns
        -------
        str
            String representation of the expression.
        """
        if self.expression is not None:
            return str(self.expression)
        return "NA"

    def as_dict(self) -> dict:
        """
        Convert the statistics aggregation to a dictionary representation.

        Returns
        -------
        dict
            Dictionary containing all relevant attributes of the statistics aggregation.
        """
        return {
            "visual_id": self.get_id(),
            "report_id": self.report_id,
            "page_number": self.page_number,
            "name": self.name,
            "description": self.desc,
            "signal_names": self.signal_names,
            "signal_expressions": [str(s) for s in self.selections],
            "aggregation_labels": self.aggregation_labels,
        }

    def as_spark_row(self) -> Row:
        """
        Convert the statistics aggregation to a Spark Row.

        Returns
        -------
        pyspark.sql.Row
            Spark Row containing the statistics aggregation data.
        """
        return Row(**self.as_dict())

    @classmethod
    def determine_aggregations(
        cls,
        spark: SparkSession,
        query: QueryBuilder,
        solver: QuerySolver,
        aggregations: list[Statistics],
    ):
        """
        Determine and process aggregations for a list of Statistics visuals.

        Parameters
        ----------
        spark : pyspark.sql.SparkSession
            Spark session to use for computation.
        query : QueryBuilder
            Query builder for constructing the query.
        solver : QuerySolver
            Solver for executing the query.
        aggregations : list of Statistics
            List of Statistics visual aggregations.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing the processed statistics aggregations.
        """
        stats_expressions = []
        stats_names = []
        for stats in aggregations:
            stats_expressions.append(stats.get_expression())
            stats_names.append(stats.get_name())

        stats_query = query.select(*stats_expressions)
        result = stats_query.solve(spark=spark, solver=solver)

        df = (
            result.transform(Statistics._unpivot_measurement_info(stats_names))
            .transform(Statistics._extract_statistics_info)
            .transform(Statistics._explode_events)
            .transform(Statistics._add_event_name_column(aggregations))
            .transform(Statistics._explode_expressions(aggregations))
            .transform(Statistics._explode_statistics)
            .transform(Statistics._add_visual_id_column(aggregations))
            .transform(Statistics._add_event_instance_id_column(aggregations))
            .select(STATISTICS_FACT_SCHEMA.fieldNames())
        )
        return df

    @staticmethod
    def _unpivot_measurement_info(stats_names: list[str]) -> Callable[..., DataFrame]:
        """
        Unpivot the measurement info columns into long format.

        Parameters
        ----------
        stats_names : list of str
            List of statistics names to unpivot.

        Returns
        -------
        function
            Function that unpivots the DataFrame columns into long format.
        """

        def _(df: DataFrame) -> DataFrame:
            return df.unpivot(
                f.col("container_id"),
                stats_names,
                variableColumnName="stats_name",
                valueColumnName="value",
            )

        return _

    @staticmethod
    def _extract_statistics_info(df: DataFrame) -> DataFrame:
        """
        Extract statistics values and event timestamps from the struct column.

        Parameters
        ----------
        df : pyspark.sql.DataFrame
            DataFrame containing statistics struct column.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame with separate columns for event timestamps and numeric values.
        """
        return df.withColumn("event_timestamps", f.col("value.event_timestamps")).withColumn(
            "numeric_values", f.col("value.numeric_values")
        )

    @staticmethod
    def _explode_events(df: DataFrame) -> DataFrame:
        """
        Explode the event timestamps array to get individual events.

        Parameters
        ----------
        df : pyspark.sql.DataFrame
            DataFrame containing event_timestamps array.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame with exploded events including start_ts and end_ts.
        """
        return (
            df.select(
                "container_id",
                "stats_name",
                "numeric_values",
                f.posexplode(f.col("event_timestamps")).alias("event_idx", "event_ts"),
            )
            .withColumn("start_ts", f.col("event_ts").getItem(0))
            .withColumn("end_ts", f.col("event_ts").getItem(1))
        )

    @staticmethod
    def _add_event_name_column(aggregations: list[Statistics]) -> Callable[..., DataFrame]:
        """
        Add the event_name column based on the statistics aggregation's event.

        Parameters
        ----------
        aggregations : list of Statistics
            List of Statistics aggregations.

        Returns
        -------
        function
            Function that adds the event_name column.
        """

        def _(df: DataFrame) -> DataFrame:
            # Build a mapping from stats_name to event_name
            col_expr = None
            for agg in aggregations:
                event = agg.get_event()
                event_name = event.get_name() if event else "NA"
                if col_expr is None:
                    col_expr = f.when(
                        f.col("stats_name") == f.lit(agg.get_name()), f.lit(event_name)
                    )
                else:
                    col_expr = col_expr.when(
                        f.col("stats_name") == f.lit(agg.get_name()), f.lit(event_name)
                    )

            if col_expr is not None:
                return df.withColumn("event_name", col_expr.otherwise(f.lit("NA")))
            return df.withColumn("event_name", f.lit("NA"))

        return _

    @staticmethod
    def _explode_expressions(aggregations: list[Statistics]) -> Callable[..., DataFrame]:
        """
        Explode the numeric_values array to get values per expression (signal).

        Parameters
        ----------
        aggregations : list of Statistics
            List of Statistics aggregations.

        Returns
        -------
        function
            Function that explodes expressions and maps signal_name.
        """

        def _(df: DataFrame) -> DataFrame:
            # First, get the values for the current event index
            # numeric_values structure: [expr][event][{stat: value}]
            # After exploding events, we need to extract values for this event from each expression
            df_with_expr = df.select(
                "container_id",
                "stats_name",
                "event_name",
                "event_idx",
                "start_ts",
                "end_ts",
                f.posexplode(f.col("numeric_values")).alias("expr_idx", "expr_event_values"),
            )

            # Now extract the stats for this specific event
            df_with_stats = df_with_expr.withColumn(
                "stats_map", f.col("expr_event_values")[f.col("event_idx")]
            )

            # Add signal_name based on expr_idx and aggregation config
            # Build mapping from (stats_name, expr_idx) -> signal_name
            col_expr = None
            for agg in aggregations:
                for idx, signal_name in enumerate(agg.signal_names):
                    condition = (f.col("stats_name") == f.lit(agg.get_name())) & (
                        f.col("expr_idx") == f.lit(idx)
                    )
                    if col_expr is None:
                        col_expr = f.when(condition, f.lit(signal_name))
                    else:
                        col_expr = col_expr.when(condition, f.lit(signal_name))

            if col_expr is not None:
                df_with_signal = df_with_stats.withColumn(
                    "signal_name", col_expr.otherwise(f.lit("unknown"))
                )
            else:
                df_with_signal = df_with_stats.withColumn("signal_name", f.lit("unknown"))

            return df_with_signal

        return _

    @staticmethod
    def _explode_statistics(df: DataFrame) -> DataFrame:
        """
        Explode the statistics map to get individual statistic values.

        Parameters
        ----------
        df : pyspark.sql.DataFrame
            DataFrame containing stats_map column.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame with exploded statistics (aggregation_label, value).
        """
        return df.select(
            "container_id",
            "stats_name",
            "event_name",
            "start_ts",
            "end_ts",
            "signal_name",
            f.explode(f.col("stats_map")).alias("aggregation_label", "value"),
        )

    @staticmethod
    def _add_visual_id_column(aggregations: list[Statistics]) -> Callable[..., DataFrame]:
        """
        Add a visual_id column to the DataFrame based on the provided visuals.

        Parameters
        ----------
        aggregations : list of Statistics
            List of Statistics visual aggregations.

        Returns
        -------
        function
            Function that adds the visual_id column to a DataFrame.
        """

        def _(df: DataFrame) -> DataFrame:
            visual_id_column = Statistics.get_visual_id_column(aggregations, "stats_name")
            return df.withColumn("visual_id", visual_id_column)

        return _

    @staticmethod
    def _add_event_instance_id_column(aggregations: list[Statistics]) -> Callable[..., DataFrame]:
        """
        Add the event_instance_id column using the shared helper function.

        Parameters
        ----------
        df : pyspark.sql.DataFrame
            DataFrame with event info columns.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame with event_instance_id column added.
        """

        def _(df: DataFrame) -> DataFrame:
            col_expr = None
            for agg in aggregations:
                agg_instance_col = ReportEntityUtil.get_event_instance_id_column(agg.get_event())
                if col_expr is None:
                    col_expr = f.when(
                        f.col("stats_name") == f.lit(agg.get_name()), agg_instance_col
                    )
                else:
                    col_expr = col_expr.when(
                        f.col("stats_name") == f.lit(agg.get_name()), agg_instance_col
                    )
            return df.withColumn(
                "event_instance_id",
                (
                    col_expr.otherwise(None)
                    if col_expr is not None
                    else f.lit(None).cast(IntegerType())
                ),
            )

        return _

    @classmethod
    def determine_metadata_df(cls, spark: SparkSession, statistics: list[Statistics]) -> DataFrame:
        """
        Create a metadata DataFrame for the provided Statistics aggregations.

        Parameters
        ----------
        spark : pyspark.sql.SparkSession
            Spark session to use for DataFrame creation.
        statistics : list of Statistics
            List of Statistics aggregations.

        Returns
        -------
        pyspark.sql.DataFrame
            DataFrame containing metadata for the statistics aggregations.
        """
        rows = [stats.as_spark_row() for stats in statistics]
        return spark.createDataFrame(rows, schema=STATISTICS_DIMENSION_SCHEMA)
