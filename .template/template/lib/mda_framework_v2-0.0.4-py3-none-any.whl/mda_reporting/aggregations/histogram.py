from __future__ import annotations

import zlib

import pyspark.sql.functions as f
from pyspark.sql import SparkSession, Row

from mda_query_engine.analyze.metadata.time_series_expression import TimeSeriesExpression
from mda_query_engine.analyze.query.query_builder import QueryBuilder
from mda_query_engine.analyze.query.solvers.query_solver import QuerySolver
from mda_reporting.aggregations.aggregation import Aggregation
from mda_reporting.events.event import Event
from mda_reporting.persist.dimension_schema import HISTOGRAM_DIMENSION_SCHEMA
from mda_reporting.persist.fact_schema import HISTOGRAM_FACT_SCHEMA
from mda_reporting.util.report_entity_util import ReportEntityUtil


class Histogram(Aggregation):
    """Class representing a histogram aggregation in a report."""

    def __init__(
        self,
        name: str,
        base_expr: TimeSeriesExpression,
        bins: list[float],
        event: Event | None = None,
        desc: str = None,
        agg_type: str = None,
        signal_name: str = None,
        values_unit: str = None,
        bins_unit: str = None,
    ):
        """
        Initialize a Histogram object.

        Parameters
        ----------
        name : str
            Name of the histogram aggregation.
        base_expr : TimeSeriesExpression
            Base time series expression to compute the histogram from.
        bins : list of float
            List of bin edges for the histogram.
        event : Event, optional
            Optional event to filter the base expression.
        desc : str, optional
            Description of the histogram.
        agg_type : str, optional
            Type of aggregation, defaults to "histogram_duration".
        signal_name : str, optional
            Name of the signal associated with the histogram.
        values_unit : str, optional
            Unit of the histogram values.
        bins_unit : str, optional
            Unit of the histogram bins.
        """
        Aggregation.__init__(self, name)
        self.base_expr = base_expr
        self.bins = bins
        self.event = event
        self.expression = self._set_expression()
        self.desc = desc
        self.agg_type = agg_type if agg_type else "histogram_duration"
        self.signal_name = signal_name
        self.values_unit = values_unit
        self.bins_unit = bins_unit

    def get_id(self) -> int:
        """
        Get a unique identifier for the histogram aggregation.

        Returns
        -------
        int
            Unique identifier for the histogram aggregation.
        """
        hash_input = f"{self.name}::{self.get_expression_str()}"
        return zlib.crc32(hash_input.encode()) & 0x7FFFFFFF  # Ensures positive 32-bit int

    def get_event(self) -> Event:
        """
        Get the event associated with the histogram.
        Returns
        -------
        Event
            The event associated with the histogram, or None if not set.
        """

        return self.event

    def _set_expression(self) -> TimeSeriesExpression:
        """
        Set the time series expression for the histogram aggregation and return histogram based on expression.
        Returns
        -------
        Histogram
            The histogram based on the time series expression.

        """
        event_expression = self.event.get_expression() if self.event else None
        expression = self.base_expr.where(event_expression) if event_expression else self.base_expr
        return expression.histogram(self.bins).alias(self.name)

    def get_expression(self) -> TimeSeriesExpression:
        """
        Get the time series expression for the histogram aggregation.
        Returns
        -------
        TimeSeriesExpression
            The time series expression for the histogram aggregation.
        """
        return self.expression

    def get_expression_str(self) -> str:
        """
        Get a string representation of the time series expression for the histogram aggregation.
        Returns
        -------
        str
            String representation of the time series expression for the histogram aggregation.
        """
        if isinstance(self.expression, TimeSeriesExpression):
            return self.expression.__str__()
        else:
            return "NA"

    def as_dict(self) -> dict:
        """
        Get a dictionary representation of the histogram aggregation.

        Returns
        -------
        dict
            Dictionary containing histohram aggregation metadata.
        """
        return {
            "visual_id": self.get_id(),
            "report_id": self.report_id,
            "name": self.name,
            "page_number": self.page_number,
            "description": self.desc,
            "agg_type": self.agg_type,
            "bins": self.bins,
            "signal_name": self.signal_name,
            "signal_expression": self.base_expr.__str__(),
            "weights_signal_name": None,
            "weights_expression": None,
            "values_unit": self.values_unit,
            "bins_unit": self.bins_unit,
        }

    def as_spark_row(self) -> Row:
        """
        Get a Spark Row representation of the histogram aggregation.

        Returns
        -------
        Row
            Spark Row containing histogram aggregation metadata.
        """
        return Row(**self.as_dict())

    @classmethod
    def determine_aggregations(
        cls,
        spark: SparkSession,
        query: QueryBuilder,
        solver: QuerySolver,
        aggregations: list[Histogram],
    ):
        """
        Determine histogram aggregation instances and return a Spark DataFrame.

        Parameters
        ----------
        spark : SparkSession
            Spark session for data processing.
        query : QueryBuilder
            Query builder for constructing aggregation queries.
        solver : QuerySolver
            Query solver for executing queries.
        aggregations : list of Histogram
            List of Histogram objects to process.

        Returns
        -------
        DataFrame
            Spark DataFrame containing histogram aggregation facts.
        """

        hist_expressions = []
        hist_names = []
        for hist in aggregations:
            hist_expressions.append(hist.get_expression())
            hist_names.append(hist.get_name())

        hist_query = query.select(*hist_expressions)

        df = (
            hist_query.solve(spark=spark, solver=solver)
            .unpivot(
                f.col("container_id"),
                hist_names,
                variableColumnName="hist_name",
                valueColumnName="value",
            )
            .withColumn("hist_values", f.col("value.H"))
            .withColumn("hist_bins", f.col("value.bin_edges"))
            .withColumn(
                "event_id",
                ReportEntityUtil.get_event_id_column(
                    elements=aggregations, element_name="hist_name"
                ),
            )
            .select(
                "container_id",
                "hist_name",
                "event_id",
                "hist_bins",
                f.posexplode(f.col("hist_values")).alias("bin_ID", "hist_value"),
            )
            .withColumn("lower_bound", f.col("hist_bins")[f.col("bin_ID")])
            .withColumn("upper_bound", f.col("hist_bins")[f.col("bin_ID") + 1])
            .withColumn("bin_name", f.concat_ws("-", "lower_bound", "upper_bound"))
            .withColumn("visual_id", Histogram.get_visual_id_column(aggregations, "hist_name"))
            .select(HISTOGRAM_FACT_SCHEMA.fieldNames())
        )
        return df

    @classmethod
    def determine_metadata_df(cls, spark: SparkSession, histograms: list[Histogram]):
        """
        Create a Spark DataFrame containing histogram aggregation metadata.

        Parameters
        ----------
        spark : SparkSession
            Spark session for data processing.
        histograms : list of Histogram
            List of Histogram objects.

        Returns
        -------
        DataFrame
            Spark DataFrame containing histogram aggregation metadata.
        """
        histograms = [hist.as_spark_row() for hist in histograms]
        return spark.createDataFrame(histograms, schema=HISTOGRAM_DIMENSION_SCHEMA)
