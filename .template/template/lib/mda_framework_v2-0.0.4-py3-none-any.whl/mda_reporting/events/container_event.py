from __future__ import annotations

import zlib

import pyspark.sql.functions as f
from pyspark.sql import SparkSession, Row

from mda_query_engine.analyze.metadata.time_series_expression import TimeSeriesExpression
from mda_query_engine.analyze.query.query_builder import QueryBuilder
from mda_query_engine.analyze.query.solvers.query_solver import QuerySolver
from mda_reporting.config.config_parser import MeasurementDimensions
from mda_reporting.events.event import Event
from mda_reporting.persist.dimension_schema import EVENT_DIMENSION_SCHEMA
from mda_reporting.persist.fact_schema import EVENT_INSTANCE_FACT_SCHEMA
from mda_reporting.util.report_entity_util import ReportEntityUtil


class ContainerEvent(Event):
    """Class representing a container-level event in a report."""

    def __init__(
        self,
        name: str,
        desc: str = None,
    ):
        """
        Initialize a ContainerEvent object.

        Parameters
        ----------
        name : str
            Name of the event.
        desc : str, optional
            Description of the event.
        """
        Event.__init__(self, name)
        self.description = desc

    def get_id(self) -> int:
        """
        Returns a unique identifier for the event.

        Returns
        -------
        int
            Unique positive 32-bit integer identifier for the event.
        """
        hash_input = f"{self.name}"
        return zlib.crc32(hash_input.encode()) & 0x7FFFFFFF

    def get_expression(self) -> TimeSeriesExpression | None:
        """
        Get the time series expression associated with the event.

        Returns
        -------
        TimeSeriesExpression or None
            None, as container events do not have a time series expression.
        """
        return None

    def as_dict(self) -> dict:
        """
        Get a dictionary representation of the event.

        Returns
        -------
        dict
            Dictionary containing event metadata.
        """
        return {
            "event_id": self.get_id(),
            "report_id": self.report_id,
            "event_name": self.name,
            "event_description": self.description,
            "required_channels": None,
            "event_expression": "NA",
        }

    def as_spark_row(self) -> Row:
        """
        Get a Spark Row representation of the event.

        Returns
        -------
        Row
            Spark Row containing event metadata.
        """
        return Row(**self.as_dict())

    @classmethod
    def determine_events(
        cls,
        spark: SparkSession,
        query: QueryBuilder,
        solver: QuerySolver,
        events: list[ContainerEvent],
    ):
        """
        Extract event fact table for the given list of ContainerEvent objects.

        Parameters
        ----------
        spark : SparkSession
            Spark session for data processing.
        query : QueryBuilder
            Query builder for constructing event queries.
        solver : QuerySolver
            Query solver for executing queries.
        events : list of ContainerEvent
            List of ContainerEvent objects to process. Expected to contain a single element.

        Returns
        -------
        DataFrame
            Spark DataFrame containing event instance facts.
        """
        # Get container metrics from solver
        container_tags_df = solver.filter_container_tags(spark, query)
        container_metrics_df = solver.filter_container_metrics(spark, query, container_tags_df)

        # Rename relevant columns to match schema
        df = (
            container_metrics_df.withColumnRenamed(
                MeasurementDimensions.CONTAINER_ID.value, "container_id"
            )
            .withColumnRenamed(MeasurementDimensions.START_TS.value, "start_ts")
            .withColumnRenamed(MeasurementDimensions.STOP_TS.value, "end_ts")
        )

        # Add event metadata columns (single event per report)
        df = (
            df.withColumn("event_name", f.lit(events[0].get_name()))
            .withColumn(
                "event_instance_id", ReportEntityUtil.get_event_instance_id_column(ContainerEvent)
            )
            .withColumn(
                "event_id",
                ReportEntityUtil.get_event_id_column(elements=events, element_name="event_name"),
            )
            .select(EVENT_INSTANCE_FACT_SCHEMA.fieldNames())
        )

        return df

    @classmethod
    def determine_metadata_df(cls, spark: SparkSession, events: list[ContainerEvent]):
        """
        Create a Spark DataFrame containing event metadata.

        Parameters
        ----------
        spark : SparkSession
            Spark session for data processing.
        events : list of ContainerEvent
            List of ContainerEvent objects.

        Returns
        -------
        DataFrame
            Spark DataFrame containing event metadata.
        """
        events = [event.as_spark_row() for event in events]
        return spark.createDataFrame(events, schema=EVENT_DIMENSION_SCHEMA)
