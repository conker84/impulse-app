from __future__ import annotations

import abc
from abc import ABC

from pyspark.sql import SparkSession, Row

from mda_query_engine.analyze.metadata.time_series_expression import TimeSeriesExpression
from mda_query_engine.analyze.query.solvers.query_solver import QuerySolver
from mda_query_engine.measurement_db import MeasurementDB


class Event(ABC):
    """Abstract base class for report events."""

    def __init__(self, name):
        """
        Initialize an Event object.

        Parameters
        ----------
        name : str
            Name of the event.
        """
        self.name = name
        self.report_id = -1  # Default value indicating no report assigned

    def get_name(self) -> str:
        """
        Get the name of the event.

        Returns
        -------
        str
            The name of the event.
        """
        return self.name

    def set_report_id(self, report_id: int):
        """
        Set the report ID for the event.

        Parameters
        ----------
        report_id : int
            The report identifier to set.

        Returns
        -------
        None
        """
        self.report_id = report_id

    @abc.abstractmethod
    def get_id(self) -> int:
        """
        Get the unique identifier for the event.

        Returns
        -------
        int
            Unique identifier for the event.
        """
        pass

    @abc.abstractmethod
    def get_expression(self) -> TimeSeriesExpression | None:
        """
        Get the expression associated with the event.

        Returns
        -------
        TimeSeriesExpression or None
            The time series expression for the event.
        """
        pass

    @abc.abstractmethod
    def as_dict(self) -> dict:
        """
        Get a dictionary representation of the event.

        Returns
        -------
        dict
            Dictionary containing representation of the event.
        """
        pass

    @abc.abstractmethod
    def as_spark_row(self) -> Row:
        """
        Get a Spark Row representation of the event.

        Returns
        -------
        Row
            Spark Row containing event info.
        """
        pass

    @classmethod
    @abc.abstractmethod
    def determine_events(
        cls, spark: SparkSession, db: MeasurementDB, solver: QuerySolver, events: list[Event]
    ):
        """
        Determine event instances and return a Spark DataFrame of event facts.

        Parameters
        ----------
        spark : SparkSession
            Spark session for data processing.
        db : MeasurementDB
            Measurement database instance.
        solver : QuerySolver
            Query solver for executing queries.
        events : list of Event
            List of Event objects to process.

        Returns
        -------
        DataFrame
            Spark DataFrame containing event instance facts.
        """
        pass

    @classmethod
    @abc.abstractmethod
    def determine_metadata_df(cls, spark: SparkSession, histograms: list[Event]):
        """
        Create a Spark DataFrame containing event metadata.

        Parameters
        ----------
        spark : SparkSession
            Spark session for data processing.
        histograms : list of Event
            List of Event objects.

        Returns
        -------
        DataFrame
            Spark DataFrame containing event metadata.
        """
        pass
