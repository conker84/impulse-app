import re
from enum import Enum
from typing import Annotated

import pyspark.sql.functions as f
from pydantic import BaseModel, AfterValidator
from pyspark.sql import Column


def is_valid_table_name(table_name: str) -> str:
    """
    Validate if a string is a valid Unity Catalog table name.

    Parameters
    ----------
    table_name : str
        The table name to validate. Should be in format 'catalog.schema.table'.

    Returns
    -------
    str
        The validated table name if valid.

    Raises
    ------
    ValueError
        If the table name does not match the required format or contains invalid characters.

    Notes
    -----
    Unity Catalog table names must:
    - Follow the format 'catalog.schema.table'
    - Each part can contain letters, numbers, hyphens and underscores
    - Each part cannot be empty
    """
    regex_valid_table_name = r"^[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+$"
    if re.fullmatch(regex_valid_table_name, table_name) is not None:
        return table_name
    else:
        raise ValueError(
            f"Invalid table name: {table_name}. Table names must be in the format 'catalog.schema.table'."
        )


def is_valid_unity_entity_name(entity_name: str) -> str:
    """
    Validate if a string is a valid Unity Catalog entity name.

    Parameters
    ----------
    entity_name : str
        The entity name to validate (catalog, schema, or table prefix).

    Returns
    -------
    str
        The validated entity name if valid.

    Raises
    ------
    ValueError
        If the entity name contains invalid characters.

    Notes
    -----
    Unity Catalog entity names must contain only letters, numbers, hyphens, and underscores.
    """
    regex_valid_entity_name = r"^[a-zA-Z0-9_-]+"
    if re.fullmatch(regex_valid_entity_name, entity_name) is not None:
        return entity_name
    else:
        raise ValueError(
            f"Invalid entity name: {entity_name}. Entity names must contain only letters, "
            f"numbers, hyphens, and underscores."
        )


class MeasurementDimensions(Enum):
    """
    Enumeration for available measurement dimensions information.
    Attributes
    ----------
    CONTAINER_ID : str
        Identifier for the container.
    UUT_ID : str
        Identifier for the unit under test (UUT).
    PROJECT_ID : str
        Identifier for the project.
    VEHICLE_KEY  : str
        Vehicle identifier.
    UUT_NAME : str
        Name of the unit under test (UUT). Currently not present in implementation.
    FILE_NAME : str
        Name of the file associated with the measurement.
    SOURCE_FILE_PATH : str
        Path to the source file containing the measurement data.
    START_TS : str
        Timestamp of the first data point in the measurement.
    STOP_TS : str
        Timestamp of the last data point in the measurement.
    ODO_START : str
        Starting odometer reading for the measurement. Currently not present in implementation.
    ODO_STOP : str
        Stopping odometer reading for the measurement. Currently not present in implementation.
    ENVIRONMENT : str
        Environment in which the measurement was taken either puma or datalogger.
    Notes
    -----
    The `get_column` method returns the corresponding Spark SQL column for each dimension.
    """

    CONTAINER_ID = "container_id"
    UUT_ID = "uut_id"
    PROJECT_ID = "project_id"  # todo not present currently
    VEHICLE_KEY = "vehicle_key"
    UUT_NAME = "uut_name"  # todo not present currently
    FILE_NAME = "file_name"
    SOURCE_FILE_PATH = "source_file_path"  #
    START_TS = "start_ts"
    STOP_TS = "stop_ts"
    ODO_START = "odo_start"  # todo not present currently
    ODO_STOP = "odo_stop"  # todo not present currently
    ENVIRONMENT = "environment"

    def get_column(self) -> Column:
        """
        Returns the corresponding Spark SQL column for the measurement dimension.
        The column names are mapped to their respective values based on the ER gold naming conventions.
        Returns
        -------
        pyspark.sql.Column
            The Spark SQL column corresponding to the measurement dimension.
        """
        measurement_dimensions_not_present_currently = [
            MeasurementDimensions.UUT_NAME,
            MeasurementDimensions.ODO_START,
            MeasurementDimensions.ODO_STOP,
        ]
        measurement_column = (
            f.lit("NOT_IMPLEMENTED")
            if self in measurement_dimensions_not_present_currently
            else f.column(self.value)
        )
        return measurement_column

    def map_gold_name_to_silver(self) -> str:
        """
        Maps the silver layer column name to the ER gold layer column name.

        Returns
        -------
        str
            The gold layer column name.
        """
        measurement_dimensions_er_gold_naming_map = {
            MeasurementDimensions.PROJECT_ID: "project",
            MeasurementDimensions.SOURCE_FILE_PATH: "file_path",
        }

        column_name = measurement_dimensions_er_gold_naming_map.get(self, self.value)
        return column_name


class DataType(str, Enum):
    RAW = "RAW"
    RLE = "RLE"


class Solvers(Enum):
    """
    Enumeration of available solver types for the query engine.

    Attributes
    ----------
    BASIC_NARROW_SOLVER : str
    DELTA_SOLVER : str
    """

    BASIC_NARROW_SOLVER = "BasicNarrowSolver"
    DELTA_SOLVER = "DeltaSolver"


class Source(BaseModel):
    """
    Configuration for data source tables in Unity Catalog.

    Attributes
    ----------
    container_metrics_table : str
        Full Unity Catalog path to the container metrics table.
    channel_metrics_table : str
        Full Unity Catalog path to the channel metrics table.
    channels_table : str
        Full Unity Catalog path to the channels data table.
    container_tags_table : Optional[str], default=None
        Optional full Unity Catalog path to the container tags table.
    channel_tags_table : Optional[str], default=None
        Optional full Unity Catalog path to the channel tags table.

    Notes
    -----
    All table names must follow Unity Catalog naming conventions:
    'catalog.schema.table' format with valid characters only.
    """

    container_metrics_table: Annotated[str, AfterValidator(is_valid_table_name)]
    channel_metrics_table: Annotated[str, AfterValidator(is_valid_table_name)]
    channels_table: Annotated[str, AfterValidator(is_valid_table_name)]

    container_tags_table: Annotated[str, AfterValidator(is_valid_table_name)] | None = None
    channel_tags_table: Annotated[str, AfterValidator(is_valid_table_name)] | None = None


class UnitySink(BaseModel):
    """
    Configuration for data sink location in Unity Catalog.

    Attributes
    ----------
    catalog : str
        Target catalog name for output tables.
    schema : str
        Target schema name for output tables.
    table_prefix : str
        Prefix to use for generated output table names.

    Notes
    -----
    All entity names must contain only letters, numbers, hyphens, and underscores.
    """

    catalog: Annotated[str, AfterValidator(is_valid_unity_entity_name)]
    schema: Annotated[str, AfterValidator(is_valid_unity_entity_name)]
    table_prefix: Annotated[str, AfterValidator(is_valid_unity_entity_name)]


class UnitUnderTestInfo(BaseModel):
    """
    Information about column name and value for unit under test.
    """

    col_name: str
    value: str | int


class UnitUnderTest(BaseModel):
    """
    Configuration for a single unit under test with time boundaries.

    Parameters
    ----------
    uut_name : UnitUnderTestInfo
        Unique identifier for the unit under test, including column name containing the specified value.
    start_ts : UnitUnderTestInfo
        Start timestamp for the analysis period, including column name containing the relevant info and value.
    end_ts : Optional[UnitUnderTestInfo], default=None
        End timestamp for the analysis period, including column name containing the relevant info and value. Optional.
    """

    uut_name: UnitUnderTestInfo
    start_ts: UnitUnderTestInfo
    end_ts: UnitUnderTestInfo | None = None


class QueryEngine(BaseModel):
    """
    Configuration for the query engine solver and optimization settings.

    Parameters
    ----------
    solver : Solvers, default=Solvers.BASIC_NARROW_SOLVER
        The solver type to use for query execution. Available options:
        - BASIC_NARROW_SOLVER: Standard solver for basic queries
        - DELTA_SOLVER: Advanced solver with RLE encoding support
    data_type : DataType, default=DataType.RLE
        The format of the input channel data. Available options:
        - RLE: Channel data is pre-encoded with Run-Length Encoding
          (intervals with ``tstart``/``tend`` columns).
        - RAW: Channel data contains raw timestamps (a ``timestamp``
          column). The framework automatically converts it to RLE
          interval format before joins and aggregations.
    drop_implausible_data : bool, default=False
        Whether to drop implausible data points before processing.
        If True, data points marked as implausible (via the
        ``is_plausible`` column) will be removed.

    Notes
    -----
    The default solver is set to `Solvers.BASIC_NARROW_SOLVER`.
    - RLE channel data must contain 'container_id', 'channel_id', 'tstart', 'tend', 'value' columns
    - RAW channel data must contain 'container_id', 'channel_id', 'timestamp', 'value' columns

    Examples
    --------
    >>> # Basic configuration with default solver
    >>> basic_engine = QueryEngine()
    >>>
    >>> # Advanced configuration with raw data and implausible data filtering
    >>> advanced_engine = QueryEngine(
    ...     solver=Solvers.DELTA_SOLVER,
    ...     data_type=DataType.RAW,
    ...     drop_implausible_data=True
    ... )
    """

    solver: Solvers = Solvers.BASIC_NARROW_SOLVER
    data_type: DataType = DataType.RLE
    drop_implausible_data: bool = False


class MdaConfig(BaseModel):
    """
     Main configuration model.

     Attributes
     ----------
     source : Source
         Configuration for input data sources.
     unity_sink : UnitySink
         Configuration for output data location.
     units_under_test : list[UnitUnderTest], optional
         Optional List of units under test with their time boundaries.
     query_engine : QueryEngine, optional
         Optional query engine configuration. Defaults to Solvers.BASIC_NARROW_SOLVER.
     measurement_dimensions : list of MeasurementDimensions, optional
         List of measurement dimensions to include in the configuration. Defaults to
         [
             MeasurementDimensions.UUT_ID,
             MeasurementDimensions.FILE_NAME,
             MeasurementDimensions.SOURCE_FILE_PATH,
             MeasurementDimensions.START_TS,
             MeasurementDimensions.STOP_TS,
             MeasurementDimensions.PROJECT_ID,
             MeasurementDimensions.ENVIRONMENT
         ].
     Examples
     --------
    >>> config_data = {
     ...     "source": {
     ...         "container_metrics_table": "mda_demo.silver.container_metric",
     ...         "channel_metrics_table": "mda_demo.silver.channel_metric",
     ...         "channels_table": "mda_demo.silver.channel_data"
     ...     },
     ...     "unity_sink": {
     ...         "catalog": "mda_demo",
     ...         "schema": "silver_refactored",
     ...         "table_prefix": "evaluation"
     ...     },
     ...     "units_under_test": [
     ...         {
     ...             "uut_name": {"col_name": "uut_id", "value": "ABCDEF"},
     ...             "start_ts": {"col_name": "start_ts", "value": "2025-04-27T05:20:54.000Z"},
     ...             "end_ts": {"col_name": "end_ts", "value": "2025-04-27T05:21:00.000Z"}
     ...         }
     ...     ],
     ...     "measurement_dimensions": [
     ...         "container_id",
     ...         "vehicle_key",
     ...         "start_ts",
     ...         "stop_ts",
     ...     ]
     ... }
     >>> config = MdaConfig.model_validate(config_data)
    """

    source: Source
    unity_sink: UnitySink
    units_under_test: list[UnitUnderTest] | None = []
    query_engine: QueryEngine = QueryEngine(solver=Solvers.BASIC_NARROW_SOLVER)

    measurement_dimensions: list[MeasurementDimensions] | None = [
        MeasurementDimensions.CONTAINER_ID,
        MeasurementDimensions.VEHICLE_KEY,
        MeasurementDimensions.START_TS,
        MeasurementDimensions.STOP_TS,
    ]
