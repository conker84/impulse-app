import json
import zlib
from typing import Any

from pyspark.sql import SparkSession

from mda_query_engine.analyze.query.query_builder import QueryBuilder
from mda_query_engine.analyze.query.solvers.basic_narrow_solver import BasicNarrowSolver
from mda_query_engine.analyze.query.solvers.delta_solver import DeltaSolver
from mda_query_engine.analyze.query.solvers.query_solver import QuerySolver
from mda_query_engine.measurement_db import MeasurementDB, MeasurementDBConfig
from mda_reporting.aggregations.aggregation_types import AggregationType
from mda_reporting.config.config_parser import MdaConfig, Solvers, DataType
from mda_reporting.core.page import Page
from mda_reporting.events.event import Event
from mda_reporting.events.event_types import EventType
from mda_reporting.meta.container_dimensions import ContainerDimension
from mda_reporting.persist.report_storage import (
    WriterFactory,
    Sink,
    SinkConfig,
    UnityCatalogSink,
    UnitySinkConfig,
)
from mda_reporting.util.report_entity_util import ReportEntityUtil


class Report:
    """Represents a report containing pages, events, and configurations for data processing and persistence."""

    def __init__(
        self,
        name: str,
        spark: SparkSession,
        config: dict[str, Any] | None = None,
        config_path: str | None = None,
    ):
        """
        Initialize the Report object.

        Parameters
        ----------
        name : str
            Name of the report.
        spark : SparkSession
            Spark session to be used for data processing.
        config : Optional[dict[str, Any]], optional
            Dictionary containing configuration parameters.
        config_path : Optional[str], optional
            Path to the JSON configuration file.
        Raises
        ------
        ValueError
            If neither config nor config_path is provided.
        """
        self.name = name
        self.report_id = self.get_id()
        self.spark = spark

        self.pages = []
        self.events = []

        self.event_dfs = {}
        self.event_metadata_dfs = {}
        self.aggregation_dfs = {}
        self.aggregation_metadata_dfs = {}
        self.container_dimension_df = None

        if config:
            self.config = Report.load_config_from_dict(config)
        elif config_path:
            self.config = Report.load_config_from_file(config_path)
        else:
            raise ValueError("Either config or config_path must be provided")

        self.db = Report.create_measurement_db(self.config)

        self.query: QueryBuilder = Report.create_query_builder(self.db, self.config)
        self.sink: Sink = Report.create_sink(self.config)

        self.solver = Report.create_solver(self.spark, self.config)

    def get_id(self) -> int:
        """
        Returns a unique identifier for the report.

        Returns
        -------
        int
            Unique positive 32-bit integer identifier for the report.
        """
        return zlib.crc32(self.name.encode()) & 0x7FFFFFFF  # Ensures positive 32-bit int

    def get_db(self) -> MeasurementDB:
        """
        Get the measurement database associated with this report.

        Returns
        -------
        MeasurementDB
            The measurement database instance.
        """
        return self.db

    def get_solver(self) -> QuerySolver:
        """
        Get the query solver associated with this report.

        Returns
        -------
        QuerySolver
            The query solver instance.
        """
        return self.solver

    @staticmethod
    def load_config_from_file(config_path: str) -> MdaConfig:
        """
        Load mda configuration from a JSON file.

        Parameters
        ----------
        config_path : str
            Path to the JSON configuration file.
        Returns
        -------
        UnitySinkConfig
            The loaded Unity sink configuration.
        """
        with open(config_path) as f:
            data = json.load(f)
        return MdaConfig.model_validate(data)

    @staticmethod
    def load_config_from_dict(config_info: dict[str, Any]) -> MdaConfig:
        """
        Load mda configuration from a dictionary.

        Parameters
        ----------
        config_info : dict of str to Any
            Dictionary containing configuration parameters.

        Returns
        -------
        MdaConfig
            The loaded mda configuration.
        """
        return MdaConfig.model_validate(config_info)

    @staticmethod
    def create_measurement_db(config: MdaConfig) -> MeasurementDB:
        """
        Create a measurement database based on the provided configuration.

        Parameters
        ----------
        config : MdaConfig
            The mda configuration.

        Returns
        -------
        MeasurementDB
            The measurement database instance.
        """
        measurement_db_config = MeasurementDBConfig(
            **dict(config.source), table_locations="unity_catalog"
        )
        return MeasurementDB(config=measurement_db_config)

    @staticmethod
    def create_query_builder(db: MeasurementDB, config: MdaConfig) -> QueryBuilder:
        """
        Create a query builder based on the provided configuration and set unit under test filter.

        Parameters
        ----------
        db : MeasurementDB
            The measurement database instance.
        config : MdaConfig
            The mda configuration.

        Returns
        -------
        QueryBuilder
            The query builder instance with applied filters.
        """
        query = db.query
        uuts_filter_cond = ReportEntityUtil.generate_uut_filter(
            query=query, units_under_test=config.units_under_test
        )
        return query.where(uuts_filter_cond)

    @staticmethod
    def create_sink(config: MdaConfig) -> Sink:
        """
        Create a sink based on the provided configuration.

        Parameters
        ----------
        config : MdaConfig
            The mda configuration.

        Returns
        -------
        Sink
            The sink instance for report persistence.
        """
        return UnityCatalogSink(
            config=UnitySinkConfig(
                catalog_name=config.unity_sink.catalog,
                schema_name=config.unity_sink.schema,
                table_prefix=config.unity_sink.table_prefix,
            )
        )

    @staticmethod
    def create_solver(spark: SparkSession, config: MdaConfig) -> QuerySolver:
        """
        Create a query solver based on the provided configuration.

        Parameters
        ----------
        spark : SparkSession
            The Spark session to use for the solver.
        config : MdaConfig
            The configuration containing solver type and optimization settings.

        Returns
        -------
        QuerySolver
            An instance of the appropriate query solver based on the configuration.

        Raises
        ------
        ValueError
            If the solver type is unknown.
        """
        match config.query_engine.solver:
            case Solvers.BASIC_NARROW_SOLVER:
                return BasicNarrowSolver(
                    spark,
                    is_raw_data=config.query_engine.data_type is DataType.RAW,
                    drop_im_plausible_data=config.query_engine.drop_implausible_data,
                )
            case Solvers.DELTA_SOLVER:
                return DeltaSolver(
                    spark,
                    is_raw_data=config.query_engine.data_type is DataType.RAW,
                    drop_implausible_data=config.query_engine.drop_implausible_data,
                )
            case _:
                raise ValueError(
                    f"Unknown query engine, we currently only support {Solvers.BASIC_NARROW_SOLVER}"
                )

    def get_sink_config(self) -> SinkConfig:
        """
        Get the current sink configuration.

        Returns
        -------
        SinkConfig
           The sink configuration associated with this report.
        """
        return self.sink.config

    def add_page(self, page: Page):
        """
        Add a page to the report.

        Parameters
        ----------
        page : Page
            The page to add.

        Returns
        -------
        None
        """
        self.pages.append(page)
        page.set_report_id(self.report_id)

    def add_event(self, event: Event):
        """
        Add an event to the report.

        Parameters
        ----------
        event : Event
            The event to add.

        Returns
        -------
        None
        """
        self.events.append(event)
        event.set_report_id(self.report_id)

    def get_events(self) -> list[Event]:
        """
        Get the list of events associated with the report.

        Returns
        -------
        list of Event
            List of events.
        """
        return self.events

    def get_events_dict(self) -> dict:
        """
        Get a dictionary of events part of the report keyed by event name.

        Returns
        -------
        dict
            Dictionary mapping event names to Event objects.
        """
        return {event.get_name(): event for event in self.events}

    def _group_events_by_type(self):
        """
        Group events by their type.

        Returns
        -------
        dict
            Dictionary mapping event type names to lists of events.
        """
        event_types = {event_type.name: [] for event_type in EventType}
        for event in self.events:
            for event_type in event_types.keys():
                if isinstance(event, EventType[event_type].value):
                    event_types[event_type].append(event)
                    break
        return event_types

    def _group_aggregations_by_type(self):
        """
        Group aggregations by their type.

        Returns
        -------
        dict
            Dictionary mapping aggregation type names to lists of aggregations.
        """
        agg_types = {agg_type.name: [] for agg_type in AggregationType}
        for page in self.pages:
            for aggregation in page.aggregations:
                for agg_type in agg_types.keys():
                    if isinstance(aggregation, AggregationType[agg_type].value):
                        agg_types[agg_type].append(aggregation)
                        break
        return agg_types

    def _validate_aggregation_events(self) -> None:
        """
        Validate that all events used in aggregations are added to the report.

        Raises
        ------
        ValueError
            If an aggregation uses an event that was not added to the report via add_event().
        """
        # Get the set of events that have been added to the report
        registered_events = set(self.events)
        registered_event_names = {event.get_name() for event in self.events}

        # Collect all events used in aggregations
        missing_events = []

        for page in self.pages:
            for aggregation in page.aggregations:
                event = aggregation.get_event()
                if event is not None and event not in registered_events:
                    event_name = event.get_name()
                    if event_name not in registered_event_names:
                        missing_events.append(
                            f"Aggregation '{aggregation.get_name()}' uses event "
                            f"'{event_name}' which was not added to the report."
                        )

        if missing_events:
            error_message = (
                "The following events are used in aggregations but were not added "
                "to the report via add_event():\n"
                + "\n".join(f"  - {msg}" for msg in missing_events)
            )
            raise ValueError(error_message)

    def persist_results(self):
        """
        Persist report results to the configured storage.

        Returns
        -------
        None
        """
        storage_factory = WriterFactory(self.sink)
        # aggregation fact tables
        for aggregation_type_str, aggregation_dfs in self.aggregation_dfs.items():
            aggregation_type = AggregationType[aggregation_type_str]
            writer = storage_factory.create_writer(aggregation_type)
            schema, uri = writer.extract_fact_schema_and_output_uri(aggregation_type)

            writer.write(aggregation_dfs, schema=schema, uri=uri)

        # aggregation dimension tables
        for (
            aggregation_type_str,
            aggregation_metadata_dfs,
        ) in self.aggregation_metadata_dfs.items():
            aggregation_type = AggregationType[aggregation_type_str]
            writer = storage_factory.create_writer(aggregation_type)

            schema, uri = writer.extract_metadata_schema_and_output_uri(aggregation_type)
            writer.write(aggregation_metadata_dfs, schema=schema, uri=uri)

        # event fact table: group by output table so BASIC_EVENT and CONTAINER_EVENT
        # are written together to the same event_instance_fact table
        event_fact_by_table = {}
        for event_type_str, event_df in self.event_dfs.items():
            table_name = EventType[event_type_str].get_fact_table_name()
            event_fact_by_table.setdefault(table_name, []).append(event_df)
        for table_name, event_dfs_list in event_fact_by_table.items():
            event_type = EventType.get_any_for_fact_table(table_name)
            writer = storage_factory.create_writer(event_type)
            schema, uri = writer.extract_fact_schema_and_output_uri(event_type)
            writer.write(event_dfs_list, schema=schema, uri=uri)

        # event dimension table: group by output table similarly
        event_metadata_by_table = {}
        for event_type_str, event_metadata_df in self.event_metadata_dfs.items():
            table_name = EventType[event_type_str].get_dimension_table_name()
            event_metadata_by_table.setdefault(table_name, []).append(event_metadata_df)
        for table_name, event_metadata_dfs_list in event_metadata_by_table.items():
            event_type = EventType.get_any_for_dimension_table(table_name)
            writer = storage_factory.create_writer(event_type)
            schema, uri = writer.extract_metadata_schema_and_output_uri(event_type)
            writer.write(event_metadata_dfs_list, schema=schema, uri=uri)

        # persist measurement dimensions
        if self.container_dimension_df:
            writer = storage_factory.create_container_dimension_writer()
            uri = writer.get_output_uri()
            writer.write(self.container_dimension_df, uri=uri)

    def determine_report(self):
        """
        Determine and process events, aggregations, and container dimensions for the report.
        Results are accessible in the report's attributes.

        Raises
        ------
        ValueError
            If any aggregation uses an event that was not added to the report.

        Returns
        -------
        None
        """
        # Validate that all events used in aggregations are registered with the report
        self._validate_aggregation_events()

        # Group events and aggregations by type
        events_by_type = self._group_events_by_type()
        aggs_by_type = self._group_aggregations_by_type()
        # Determine events
        event_dfs = {}
        event_metadata_dfs = {}
        for event_name, events in events_by_type.items():
            if not events:
                continue
            cls = EventType[event_name].value
            # Determine fact table for events
            event_df = cls.determine_events(
                self.spark, self.query, self.solver, events_by_type[EventType[event_name].name]
            )
            event_dfs[event_name] = event_df

            # Determine metadata for events
            event_metadata_df = cls.determine_metadata_df(
                self.spark, events_by_type[EventType[event_name].name]
            )
            event_metadata_dfs[event_name] = event_metadata_df
        self.event_dfs = event_dfs
        self.event_metadata_dfs = event_metadata_dfs

        # Determine aggregations
        aggregation_dfs = {}
        aggregation_metadata_dfs = {}
        for agg_name, aggregations in aggs_by_type.items():
            if not aggregations:
                continue
            cls = AggregationType[agg_name].value
            # Determine fact table for aggregations
            aggregation_df = cls.determine_aggregations(
                self.spark, self.query, self.solver, aggs_by_type[AggregationType[agg_name].name]
            )
            aggregation_dfs[agg_name] = aggregation_df

            # Determine metadata for aggregations
            aggregation_metadata_df = cls.determine_metadata_df(
                self.spark, aggs_by_type[AggregationType[agg_name].name]
            )
            aggregation_metadata_dfs[agg_name] = aggregation_metadata_df

        self.aggregation_dfs = aggregation_dfs
        self.aggregation_metadata_dfs = aggregation_metadata_dfs

        # Determine container dimension
        self.container_dimension_df = ContainerDimension.get_dimension(
            spark=self.spark, query=self.query, solver=self.solver, config=self.config
        )
