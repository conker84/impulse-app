class PageFooter:
    pass
